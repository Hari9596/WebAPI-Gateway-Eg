﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace ProductAPI.Controllers
{
    [Route("api/product")]
    [ApiController]
    public class ProductController : ControllerBase
    {
        [HttpGet("getproduct")]
        public ActionResult<IEnumerable<string>> Get()
        {
            Product product = GetDummyData();
            return Ok(product);
        }


        private Product GetDummyData()
        {
            Product product = new Product
            {
                Id = 1,
                Name = "Alexa",
                Price = "$98"
            };
            return product;
        }

        public class Product
        {
            public int Id { get; set; }
            public string Name { get; set; }
            public string Price { get; set; }
        }
    }
}